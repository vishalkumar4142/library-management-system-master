import { Borrow } from './borrow';

describe('Borrow', () => {
  it('should create an instance', () => {
    expect(new Borrow()).toBeTruthy();
  });
});
